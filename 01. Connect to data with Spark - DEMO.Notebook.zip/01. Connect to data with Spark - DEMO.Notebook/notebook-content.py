# Fabric notebook source

# METADATA ********************

# META {
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "b138bd89-9b90-43f2-bf3f-b11db7ec4fb8",
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": "",
# META       "known_lakehouses": [
# META         {
# META           "id": "b138bd89-9b90-43f2-bf3f-b11db7ec4fb8"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# #**Learn Together: Ingest data with Spark and Microsoft Fabric notebooks**
# 
# https://www.youtube.com/watch?v=r-ZYUW7qL-o&list=PL1N57mwBHtN0-AJVURyfqbdmX65JMXSVv&index=15

# MARKDOWN ********************

# https://microsoftlearning.github.io/mslearn-fabric/Instructions/Labs/10-ingest-notebooks.html

# MARKDOWN ********************

# #abfss://eecd62f8-44b6-4a5c-aed5-7255c0031897@onelake.dfs.fabric.microsoft.com/b138bd89-9b90-43f2-bf3f-b11db7ec4fb8/Files/RawData

# CELL ********************

 # Azure Blob Storage access info
 blob_account_name = "azureopendatastorage"
 blob_container_name = "nyctlc"
 blob_relative_path = "yellow"
    
 # Construct connection path
 wasbs_path = f'wasbs://{blob_container_name}@{blob_account_name}.blob.core.windows.net/{blob_relative_path}'
 print(wasbs_path)
    
 # Read parquet data from Azure Blob Storage path
 blob_df = spark.read.parquet(wasbs_path)


# CELL ********************

#blob_df.show()
display(blob_df.head(5))

# CELL ********************

     # Declare file name    
     file_name = "yellow_taxi"
    
     # Construct destination path
     output_parquet_path = f"**InsertABFSPathHere**/{file_name}"
     print(output_parquet_path)
        
     # Load the first 1000 rows as a Parquet file
     blob_df.limit(1000).write.mode("overwrite").parquet(output_parquet_path)

# MARKDOWN ********************

# **#reading data from azure sql database in notebook - microsoft fabric**
# 
# https://www.google.com/search?q=reading+data+from+azure+sql+database+in+notebook+-+microsoft+fabric&sca_esv=a44e7edcd40cf9fd&biw=1536&bih=703&tbm=vid&ei=kYUwZtrJPNWF9u8P_qqBoAk&ved=0ahUKEwia1vuQnumFAxXVgv0HHX5VAJQQ4dUDCA0&uact=5&oq=reading+data+from+azure+sql+database+in+notebook+-+microsoft+fabric&gs_lp=Eg1nd3Mtd2l6LXZpZGVvIkNyZWFkaW5nIGRhdGEgZnJvbSBhenVyZSBzcWwgZGF0YWJhc2UgaW4gbm90ZWJvb2sgLSBtaWNyb3NvZnQgZmFicmljSLIiUOsOWNoccAF4AJABAJgBUqABjwSqAQE4uAEDyAEA-AEBmAIBoAJUwgIEECEYCpgDAIgGAZIHATGgB5sG&sclient=gws-wiz-video

# CELL ********************

#FOR INFO

# Placeholders for Azure SQL Database connection info
server_name = "your_server_name.database.windows.net"
port_number = 1433  # Default port number for SQL Server
database_name = "your_database_name"
table_name = "YourTableName" # Database table
client_id = "YOUR_CLIENT_ID"  # Service principal client ID
client_secret = "YOUR_CLIENT_SECRET"  # Service principal client secret
tenant_id = "YOUR_TENANT_ID"  # Azure Active Directory tenant ID


# Build the Azure SQL Database JDBC URL with Service Principal (Active Directory Integrated)
jdbc_url = f"jdbc:sqlserver://{server_name}:{port_number};database={database_name};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;Authentication=ActiveDirectoryIntegrated"
#https://www.google.com/search?q=AZURE+SQL+DATABASE+JDBC+URL+with+service+Principal&sca_esv=a44e7edcd40cf9fd&biw=1536&bih=703&tbm=vid&ei=woUwZo7ID4SA9u8PovOouAk&ved=0ahUKEwiOsf2nnumFAxUEgP0HHaI5CpcQ4dUDCA0&oq=AZURE+SQL+DATABASE+JDBC+URL+with+service+Principal&gs_lp=Eg1nd3Mtd2l6LXZpZGVvIjJBWlVSRSBTUUwgREFUQUJBU0UgSkRCQyBVUkwgd2l0aCBzZXJ2aWNlIFByaW5jaXBhbDIIEAAYgAQYogQyCBAAGIAEGKIEMggQABiABBiiBEjiKlAAWOcYcAB4AJABAJgBnQGgAecBqgEDMS4xuAEMyAEA-AEC-AEBmAICoAL6AcICBxAhGKABGAqYAwCSBwMxLjGgB9QF&sclient=gws-wiz-video
#???https://www.google.com/search?q=AZURE+SQL+DATABASE+JDBC+URL+with+service+Principal&sca_esv=a44e7edcd40cf9fd&biw=1536&bih=703&tbm=vid&ei=woUwZo7ID4SA9u8PovOouAk&ved=0ahUKEwiOsf2nnumFAxUEgP0HHaI5CpcQ4dUDCA0&oq=AZURE+SQL+DATABASE+JDBC+URL+with+service+Principal&gs_lp=Eg1nd3Mtd2l6LXZpZGVvIjJBWlVSRSBTUUwgREFUQUJBU0UgSkRCQyBVUkwgd2l0aCBzZXJ2aWNlIFByaW5jaXBhbDIIEAAYgAQYogQyCBAAGIAEGKIEMggQABiABBiiBEjiKlAAWOcYcAB4AJABAJgBnQGgAecBqgEDMS4xuAEMyAEA-AEC-AEBmAICoAL6AcICBxAhGKABGAqYAwCSBwMxLjGgB9QF&sclient=gws-wiz-video


# Properties for the JDBC connection
properties = {
    "user": client_id, 
    "password": client_secret,  
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    "tenantId": tenant_id  
}


# Read entire table from Azure SQL Database using AAD Integrated authentication
sql_df = spark.read.jdbc(url=jdbc_url, table=table_name, properties=properties)

#Diplay the Azure SQL DataFrame
display(sql_df)
#sql_df.show()





# MARKDOWN ********************

# #Write to a file

# CELL ********************

# Write DataFrame to Parquet file format
parquet_output_path = "your_folder/your_file_name"
df.write.mode("overwrite").parquet(parquet_output_path)
print(f"DataFrame has been written to Parquet file: {parquet_output_path}")

# Write DataFrame to Delta table
delta_table_name = "your_delta_table_name"
df.write.format("delta").mode("overwrite").saveAsTable(delta_table_name)
print(f"DataFrame has been written to Delta table: {delta_table_name}")

# MARKDOWN ********************

#  Explore core data concepts
# 
# https://learn.microsoft.com/en-us/training/modules/explore-core-data-concepts/?WT.mc_id=academic-116609-lbugnion

# MARKDOWN ********************


# MARKDOWN ********************

# Write to a delta table

# CELL ********************

# Use format and save to load as a Delta table
table_name = "nyctaxi_raw"
filtered_df.write.mode("overwrite").format("delta").save(f"Tables/{table_name}")

# Confirm load as Delta table
print(f"Spark DataFrame saved to Delta table: {table_name}")

# MARKDOWN ********************

# Optimize Delta table writes
# 
# https://learn.microsoft.com/en-us/fabric/data-engineering/delta-optimization-and-v-order?tabs=sparksql&WT.mc_id=academic-116609-lbugnion


# CELL ********************

# Enable V-Order 
spark.conf.set("spark.sql.parquet.vorder.enabled", "true")

# Enable automatic Delta optimized write
spark.conf.set("spark.microsoft.delta.optimizeWrite.enabled", "true")
